/**Hamnah Irfan 
 * Program 3
 * Decisions
 */

package com.mycompany.p2irfan;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class P2Irfan 
{
    static Resident resident1, resident2, resident3; 
    
    public static void main(String[] args) 
    {
        resident1 = new Resident();
        resident2 = new Resident();
        resident1.input();
        resident3 = new Resident("Harry Jones", "18 Base Hollow Road", 
                "123-4567", 50.20 );
        
        /*System.out.println(resident1);
        System.out.println(resident2);
        System.out.println(resident3);*/
       
        
        /*resident1.showSC();*/
        /*resident2.showSC();*/
        /*resident3.showSC();*/
        
        /*resident3.showMB();*/
        /*System.out.println(resident1.toString());*/
        
        /*System.out.println(resident3.calculateArea());*/
        
        /*System.out.println(resident3.getName());*/
        /*System.out.println(resident3.getAddress());*/
        /*System.out.println(resident3.getPhoneNumber());*/
        /*System.out.println(resident3.getPlotRadius());*/
        
        /*resident2.setName("Samantha");
        System.out.println(resident2.getName());*/
        
        /*resident2.setAddress("23 Smith Drive");
        System.out.println(resident2.getAddress());
        
        resident2.setPhoneNumber("987-654-3210");
        System.out.println(resident2.getPhoneNumber());
        
        resident2.setPlotRadius(34.987);
        System.out.println(resident2.getPlotRadius());*/
        
        
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        double resident1Area = resident1.calculateArea();
        double resident2Area = resident2.calculateArea();
        double resident3Area = resident3.calculateArea();
        
        resident1.showSC();
        System.out.println("The area of your plot is: " + 
                    df.format(resident1Area) + " square feet \n");
        
        
        resident2.showSC();
        System.out.println("The area of your plot is: " + 
                    df.format(resident2Area) + " square feet \n");
        
        resident3.showMB();
        JOptionPane.showMessageDialog(null,"The area of your plot is: " + 
                    df.format(resident3Area) + " square feet");
        
        /*System.out.println(resident1Area);
        
        System.out.println(resident1.computeTax(resident1Area));
        
        System.out.println(resident1.taxRate(resident1Area));*/
        
        /*TAX BILL */
        
        JOptionPane.showMessageDialog(null, "*********** TAX BILL "
                + "*********** \n" + "For " + resident1.getName() + " of " 
                + resident1.getAddress()+ "\n \t \t \t" 
                + resident1.taxRate(resident1Area)
                + "\nYou owe " + resident1.computeTax(resident1Area)
                + ", due on " + resident1.dueDate(resident1.getName()));
        
        JOptionPane.showMessageDialog(null, "*********** TAX BILL "
                + "*********** \n" + "For " + resident2.getName() + " of " 
                + resident2.getAddress()+ "\n \t \t \t" 
                + resident2.taxRate(resident2Area)
                + "\nYou owe " + resident2.computeTax(resident2Area)
                + ", due on " + resident2.dueDate(resident2.getName()));
        
        JOptionPane.showMessageDialog(null, "************* TAX BILL "
                + "************* \n" + "For " + resident3.getName() + " of " 
                + resident3.getAddress()+ "\n \t \t \t \t \t" 
                + resident3.taxRate(resident3Area)
                + "\nYou owe " + resident3.computeTax(resident3Area)
                + ", due on " + resident3.dueDate(resident3.getName()));
        
        
        int lottery;
        lottery = (int)(1.0 + Math.random() * (3.0 - 1.0));
        
        switch (lottery)
        {
            case 1:
                JOptionPane.showMessageDialog(null, "\t The Winner of Tax "
                        + "Lottery is: \n \t" + resident1.getName() + " of " 
                        + resident1.getAddress());
                break;
            case 2: 
                JOptionPane.showMessageDialog(null, "\t The Winner of Tax "
                        + "Lottery is: \n \t" + resident2.getName() + " of " 
                        + resident2.getAddress());
                break;
                
            default: 
                JOptionPane.showMessageDialog(null, "\t The Winner of Tax "
                        + "Lottery is: \n \t" + resident3.getName() + " of " 
                        + resident3.getAddress());       
        }
        
    }
    
}
