/*Hamnah Irfan
Program 5
Arrays
COM152
*/

package com.mycompany.p5irfan;

import java.util.Arrays;
import javax.swing.JOptionPane;

public class P5Irfan 
{

    public static void main(String[] args) 
    {
        String s; 
        int n; 
        int summ = 0;
        int average;
        
        do
        {
            s = JOptionPane.showInputDialog("Welcome to the Happy Valley age "
                + "analysis \nand lottery program. \nHow many people currently "
                + "reside in the village?");
        } while (s == null || s.equals("")); 
        
        n = Integer.parseInt(s);
        
        String[] name; 
        int[] age; 
        name = new String[n];
        age = new int[n];
        
        for (int i = 0; i < n; i++)
        {
            name[i] = JOptionPane.showInputDialog("Enter a person's name");
            age[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter " + 
                    name[i] + "'s age and click OK"));
        }
        
        
        
        /*System.out.println(Arrays.toString(name));
        System.out.println(Arrays.toString(age));*/
        
            for (int i = 0; i < age.length; i++)
            {
                summ = summ + age[i];
            }
            
            average = summ / age.length; 
            
        int min = age[0];
        int minsIndex = 0;
        for(int i = 1; i < age.length; i++)
        {
            if(age[i] < min)
            {
                min = age[i];
                minsIndex = i;
            }
        }
        
        int max = age[0];
        int maxIndex = 0;
        for(int i = 1; i < age.length; i++)
        {
            if(age[i] > max)
            {
                max = age[i];
                maxIndex = i;
            }
        }
            
        System.out.println("The average age of all the people is " + average 
                + ". \nAnd prize winners names are " + name[minsIndex] + ", and "
                +name[maxIndex] + "\nThe oldest person is " + age[maxIndex] + 
                ".\nThe yougest person is " + age[minsIndex] + ".");
            
    }
}
