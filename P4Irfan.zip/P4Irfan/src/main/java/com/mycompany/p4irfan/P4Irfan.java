package com.mycompany.p4irfan;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class P4Irfan 
{
    public static void main(String[] args) 
    {
        String name;
        String s;
        String transactionGrouping;
        String password;
        String caseSensitivePassword = "ABCD";
        int nTransactions;
        double balance = 1000.00;
        double transactionAmount;
        double transactionTotal;
        
        do 
        {
            name = JOptionPane.showInputDialog("Welcome to the Piggy Bank.\n"
                    + "Please enter your name");
        } while (name == null || name.equals("")); 
        
        do 
        {
            password = JOptionPane.showInputDialog("Enter your Password");           
        } while (!password.equals(caseSensitivePassword));
        
        do
        {
            transactionGrouping = JOptionPane.showInputDialog("Is this "
                    + "transaction grouping deposits (as opposed to a group of "
                    + "withdrawals)? Yes or no?");
            
            s = JOptionPane.showInputDialog("How many transactions in this "
                    + "grouping?");
            
            nTransactions = Integer.parseInt(s);
            transactionTotal = 0;
            
            for (int i = 1; i <= nTransactions; i++)
            {
                s = JOptionPane.showInputDialog("Enter a transaction amount,\n"
                        + "Click Cancel to end");
                
                transactionAmount = Double.parseDouble(s);
                
                   if(transactionGrouping.equalsIgnoreCase("yes"))
                   {
                        transactionTotal = transactionTotal + transactionAmount;
                        balance = balance + transactionAmount;
                   }
                   else 
                   {
                        transactionTotal = transactionTotal + transactionAmount;
                        balance = balance - transactionAmount;
                   }   
            }
            
            DecimalFormat df = new DecimalFormat("$#,##0.00");
            s = JOptionPane.showInputDialog(name + ", the total of the " 
                    + nTransactions + " transactions in this group of transactions"
                    + " is: " + df.format(transactionTotal) + "\nYour new"
                    + " balance is: " + df.format(balance) + "\nDon't make an "
                    + "input, just Click: OK to continue, Cancel to exit the "
                    + "program"); 
         
        } while (s != null);
        
    }
}

