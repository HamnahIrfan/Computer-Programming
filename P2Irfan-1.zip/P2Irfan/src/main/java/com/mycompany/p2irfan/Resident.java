/**Hamnah Irfan 
 * Program 2
 * Object Oriented Programming
 */

package com.mycompany.p2irfan;

import static com.mycompany.p2irfan.P2Irfan.resident2;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Resident 
{
    /*data members*/
    private String name = "Ms. Smith";
    private String address = "First Street";
    private String phoneNumber = "631 123-4567";
    private double plotRadius = 10.00; 
    
    public Resident()
    {
        
    }
    
    public Resident(String name, String address, String phoneNumber,
            double plotRadius)
    {
       this.name = name; 
       this.address = address; 
       this.phoneNumber = phoneNumber; 
       this.plotRadius = plotRadius; 
    }
    
    public void input()
    {
        String s = JOptionPane.showInputDialog("Please enter your name:");
        name = s; 
        
        s = JOptionPane.showInputDialog("Please enter your address"
                + ":");
        address = s;
        
        s = JOptionPane.showInputDialog("Please enter your "
                + "phone number:");
        phoneNumber = s;
        
        s = JOptionPane.showInputDialog("Please enter the "
                + "radius of your plot (in feet):");
        plotRadius = Double.parseDouble(s);
      
    }
    
    @Override
    public String toString()
    {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        String s;
        s = "Your name is:" + " \"" + name +"\"" + "\n" + "Your address " 
                + "is: " + " \"" + address +"\"" + "\n" + "Your phone number "
                + "is: " + " \"" + phoneNumber +"\"" + "\n" + "The radius of "
                + "your plot" + " is: " + " \"" + df.format(plotRadius) + 
                " feet" +"\"" +"\n";
        return s;
    }
    
    public void showSC()
    {
        System.out.println(this.toString());
    }
    
    public void showMB()
    {
       JOptionPane.showMessageDialog(null,this.toString()); 
    }
    
    public String getName()
    {
        return name; 
    }
    
    public String getAddress()
    {
        return address;
    }
    
    public String getPhoneNumber()
    {
        return phoneNumber;
    }
    
    public double getPlotRadius()
    {
        return plotRadius;
    }
    
    public void setName(String name)
    {
        this.name = name;   
    }
    
    public void setAddress(String address)
    {
        this.address = address;  
    }
    
    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    
    public void setPlotRadius(double plotRadius)
    {
        this.plotRadius= plotRadius;
    }
    
    public double calculateArea()
    {
        double area = Math.PI * Math.pow(plotRadius, 2.0); 
        return area;   
    }
    
}
    

    

    

