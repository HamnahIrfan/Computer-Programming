/**Hamnah Irfan 
 * Program 2
 * Object Oriented Programming
 */

package com.mycompany.p2irfan;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class P2Irfan 
{
    static Resident resident1, resident2, resident3; 
    
    public static void main(String[] args) 
    {
        resident1 = new Resident();
        resident2 = new Resident();
        resident1.input();
        resident3 = new Resident("Harry Jones", "18 Base Hollow Road", 
                "123-4567", 50.20 );
        
        /*System.out.println(resident1);
        System.out.println(resident2);
        System.out.println(resident3);*/
       
        
        /*resident1.showSC();*/
        /*resident2.showSC();*/
        /*resident3.showSC();*/
        
        /*resident3.showMB();*/
        /*System.out.println(resident1.toString());*/
        
        /*System.out.println(resident3.calculateArea());*/
        
        /*System.out.println(resident3.getName());*/
        /*System.out.println(resident3.getAddress());*/
        /*System.out.println(resident3.getPhoneNumber());*/
        /*System.out.println(resident3.getPlotRadius());*/
        
        /*resident2.setName("Samantha");
        System.out.println(resident2.getName());*/
        
        /*resident2.setAddress("23 Smith Drive");
        System.out.println(resident2.getAddress());
        
        resident2.setPhoneNumber("987-654-3210");
        System.out.println(resident2.getPhoneNumber());
        
        resident2.setPlotRadius(34.987);
        System.out.println(resident2.getPlotRadius());*/
        
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        resident1.showSC();
        System.out.println("The area of your plot is: " + 
                    df.format(resident1.calculateArea()) + " square feet \n");
        
        
        resident2.showSC();
        System.out.println("The area of your plot is: " + 
                    df.format(resident2.calculateArea()) + " square feet \n");
        
        resident3.showMB();
        JOptionPane.showMessageDialog(null,"The area of your plot is: " + 
                    df.format(resident3.calculateArea()) + " square feet");
        
    }
    
}
