///Hamnah Irfan 
///COM152
///Program 1 
///Input, Output, Strings, Math and the Math Class, and Programming Style

package com.mycompany.irfanp1;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class IrfanP1 
{
    public static void main(String[] args) 
    {
        ///inital message
        JOptionPane.showMessageDialog(null, "Follow the instructions to "
                + "calculate the area of your plot");
        
        ///inputs: name, address, phone number, and radius of plot
        String name = JOptionPane.showInputDialog("Please enter your name:");
        String address = JOptionPane.showInputDialog("Please enter your address"
                + ":");
        String phoneNumber = JOptionPane.showInputDialog("Please enter your "
                + "phone number:");
        String radius = JOptionPane.showInputDialog("Please enter the "
                + "radius of your plot (in feet):");
        
        ///parse the string radius into a double
        double plotRadius = Double.parseDouble(radius);
        
        ///output to the system console
        System.out.println("Your name is:" + " \"" + name +"\"" + ",");
        System.out.println("Your address is: " + address);
        System.out.println("Your phone number is: " + phoneNumber);
        System.out.println("The radius of your plot is: " + plotRadius + " feet");
        
        /// calculating the area
        double area = Math.PI * Math.pow(plotRadius, 2.0); 
        
        ///Formatting the area 
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        ///To the MessageBox
        JOptionPane.showMessageDialog(null, "Your plot size is: " + 
                df.format(area) + " square feet \nHave a nice day!");    
    }
}
